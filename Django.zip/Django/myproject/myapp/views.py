from django.shortcuts import render, redirect
from .models import Student

# READ
def student_list(request):
    students = Student.objects.all()
    return render(request, 'students/list.html', {'students': students})

# CREATE
def student_create(request):
    if request.method == "POST":
        Student.objects.create(
            name=request.POST['name'],
            email=request.POST['email'],
            age=request.POST['age']
        )
        return redirect('/')
    return render(request, 'students/add.html')

# UPDATE
def student_update(request, id):
    student = Student.objects.get(id=id)
    if request.method == "POST":
        student.name = request.POST['name']
        student.email = request.POST['email']
        student.age = request.POST['age']
        student.save()
        return redirect('/')
    return render(request, 'students/edit.html', {'student': student})

# DELETE
def student_delete(request, id):
    student = Student.objects.get(id=id)
    student.delete()
    return redirect('/')



# Create your views here.
