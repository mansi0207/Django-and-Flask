from flask import Flask, render_template, request
app = Flask(__name__)
@app.route('/')
def form():
    return render_template('home.html')
@app.route('/result',methods=['POST'])
def result():
    name = request.form['name']
    age = request.form['age']
    return render_template('about.html', name=name, age=age)

if __name__ == '__main__':
    app.run(debug=True)
    





# def home():
#     return render_template("home.html")
# @app.route('/about')
# def about():
#     return render_template("about.html")
# @app.route('/contact')
# def contact():
#     return render_template("contact.html")
# @app.route('/index')  
# def index():
#     return render_template("index.html")

# if __name__ == '__main__':
#     app.run(debug=True)