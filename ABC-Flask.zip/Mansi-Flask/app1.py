
from flask import Flask, render_template
app1 = Flask(__name__) 

@app1.route("/profile")
def profile():
    return render_template(
        "profile.html",
        name="Mansi",
        age=22,
        Course="Flask"
    )

@app1.route("/courses")
def courses():
    course_list = ["Flask", "Django", "FastAPI"]
    return render_template("courses.html", courses=course_list)

@app1.route("/student")
def student():
    data = {"name": "Mansi", "course": "Flask"}
    return render_template("student.html", student=data)

@app1.route("/login_status")
def login_status():
    return render_template("status.html", is_logged_in=True)
if __name__ == "__main__":
    app1.run(debug=True)