from flask import Flask, render_template, request
import pywhatkit
import time

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    status = ""

    if request.method == "POST":
        phone = request.form["phone"]
        message = request.form["message"]

        try:
            # Send instantly
            pywhatkit.sendwhatmsg_instantly(
                phone_no=phone,
                message=message,
                wait_time=15,     # seconds before sending
                tab_close=True
            )
            status = "✅ Message sent successfully!"

        except Exception as e:
            status = f"❌ Error: {str(e)}"

    return render_template("index.html", status=status)

if __name__ == "__main__":
    app.run(debug=True)